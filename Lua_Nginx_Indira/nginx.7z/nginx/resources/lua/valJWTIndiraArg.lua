function GetValueFromXML(XML_string, XMLvalue)
   local XMLvalueLength=string.len(XMLvalue)+2
   local XMLvalueStartPos=string.find(XML_string,"<" .. XMLvalue .. ">")+XMLvalueLength
   local XMLvalueEndPos=string.find(XML_string,"</" .. XMLvalue .. ">")
   local ReturnValue=string.sub(XML_string,XMLvalueStartPos,XMLvalueEndPos-1)
   return ReturnValue
end

ngx.req.read_body()  -- explicitly read the req body
local bodyXml = ngx.req.get_body_data()

local jwt_token = (GetValueFromXML(bodyXml,"ser:Token") .. "." .. GetValueFromXML(bodyXml,"ser:Sign"))

ngx.req.set_header("Content-Type", "application/xml")
ngx.req.set_header("authorization", "Bearer " .. jwt_token)
ngx.exec('/validate-auid-indira');