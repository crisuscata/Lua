function GetValueFromXML(XML_string, XMLvalue)
   local XMLvalueLength=string.len(XMLvalue)+2
   local XMLvalueStartPos=string.find(XML_string,"<" .. XMLvalue .. ">")+XMLvalueLength
   local XMLvalueEndPos=string.find(XML_string,"</" .. XMLvalue .. ">")
   local ReturnValue=string.sub(XML_string,XMLvalueStartPos,XMLvalueEndPos-1)
   return ReturnValue
end

ngx.req.read_body()  -- explicitly read the req body
local reqXml = ngx.req.get_body_data()

local testXml = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">'
testXml = testXml .. '<soap:Body>'
testXml = testXml .. '<consultadeclaracionResponse xmlns="http://serviciosmercosur.indira">'
testXml = testXml .. '<consultadeclaracionResult>'
local okNumDecl, resultNumDecl = pcall(GetValueFromXML, reqXml, "ser:numeroDeclaracion") 
if(okNumDecl) then
	testXml = testXml .. '<numeroDeclaracion>' .. resultNumDecl  .. '</numeroDeclaracion>'
end

local okTipDecl, resultTipDecl = pcall(GetValueFromXML, reqXml, "ser:tipoDeclaracion") 
if(okTipDecl) then
	testXml = testXml .. '<tipoDeclaracion>'.. resultTipDecl .. '</tipoDeclaracion>'
end
testXml = testXml .. '<totalBultos>0</totalBultos>'
testXml = testXml .. '<cantidadItems>0</cantidadItems>'
testXml = testXml .. '<valorFleteTotal>0</valorFleteTotal>'
testXml = testXml .. '<valorSeguroTotal>0</valorSeguroTotal>'
testXml = testXml .. '<valorFobTotal>0</valorFobTotal>'
testXml = testXml .. '<valorTotalCondicionVentaDolares>0</valorTotalCondicionVentaDolares>'
testXml = testXml .. '<pesoBrutoTotal>0</pesoBrutoTotal>'
testXml = testXml .. '<codigoError>7008</codigoError>'
testXml = testXml .. '</consultadeclaracionResult>'
testXml = testXml .. '</consultadeclaracionResponse>'
testXml = testXml .. '</soap:Body>'
testXml = testXml .. '</soap:Envelope>'

ngx.status = 200  
ngx.say(testXml)  
return ngx.exit(200) 